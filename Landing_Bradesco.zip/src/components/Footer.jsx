import React from 'react';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Linkedin, Mail, Phone, MapPin } from 'lucide-react';
const Footer = () => {
  const bradescoLogoUrl = "https://horizons-cdn.hostinger.com/ed85e735-d490-4d03-b643-9cc80ad837a3/743f1aa297a5e0b175755c4bee4918e5.png";
  const abmixLogoUrl = "https://horizons-cdn.hostinger.com/ed85e735-d490-4d03-b643-9cc80ad837a3/6266925ed6f4b7adabc2f0b43a8568e3.png";
  return <motion.footer initial={{
    opacity: 0,
    y: 20
  }} animate={{
    opacity: 1,
    y: 0
  }} transition={{
    duration: 0.6,
    delay: 0.2
  }} className="bg-bradesco-red text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          
          <div className="flex flex-col items-center md:items-start">
            <div className="flex flex-col sm:flex-row items-center gap-4 mb-4">
              <img src={bradescoLogoUrl} alt="Logo Bradesco Saúde" className="h-24 w-auto" />
              <img src={abmixLogoUrl} alt="Logo ABMIX Corretora" className="h-24 w-auto" />
            </div>
            <p className="text-xs text-center md:text-left text-gray-300">© 2024 ABMIX Corretora. Todos os direitos reservados. Este site é operado pela ABMIX e não é o site oficial da Bradesco Saúde.</p>
          </div>

          <div className="text-center">
            <span className="font-bold text-base mb-3 block">Contato</span>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center justify-center gap-2">
                <Phone className="h-4 w-4" />
                <span>(11) 99616-3900</span>
              </li>
              <li className="flex items-center justify-center gap-2">
                <Mail className="h-4 w-4" />
                <span>contato@abmix.com.br</span>
              </li>
              <li className="flex items-center justify-center gap-2">
                <MapPin className="h-4 w-4" />
                <span>Rua. Padre Adelino 2074 CONJ. 21</span>
              </li>
            </ul>
          </div>

          <div className="flex flex-col items-center md:items-end">
            <div className="text-center md:text-right">
              <span className="font-bold text-base mb-3 block">Redes Sociais</span>
              <div className="flex justify-center md:justify-end space-x-4">
                <a href="https://www.facebook.com/abmixcorretoraeconsultoria/?locale=pt_BR" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-300 transition-colors">
                  <Facebook className="h-6 w-6" />
                </a>
                <a href="https://www.instagram.com/abmixcorretora/" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-300 transition-colors">
                  <Instagram className="h-6 w-6" />
                </a>
                <a href="https://br.linkedin.com/company/abmixcorretora" target="_blank" rel="noopener noreferrer" className="text-white hover:text-gray-300 transition-colors">
                  <Linkedin className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="bg-bradesco-red-dark py-3">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-xs text-gray-300">
          <p>
            Site exclusivo para divulgação de planos de saúde Bradesco – Revenda Autorizada.
            ABMIX SOLUÇÕES EM SEGUROS LTDA – CNPJ: 49.265.105/0001-61 – Tel: (11) 99616-3900.
          </p>
          <p className="mt-1">
            Este site é destinado apenas à intermediação de vendas e não é o site oficial da Bradesco Saúde.
          </p>
        </div>
      </div>
    </motion.footer>;
};
export default Footer;